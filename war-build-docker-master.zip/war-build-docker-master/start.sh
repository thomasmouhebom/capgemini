docker run -d --name test -p 8080:8080 webtom
